#!/system/bin/sh
# Honor Charge Unlock daemon - KSU/Magisk compatible
# Removes the OS screen-on charging power cap by resetting direct-charge
# iin_thermal limits (the charge FW recomputes them to its max when set to 0).
MODDIR=${0%/*}
CONF=/data/adb/honor_charge_unlock.conf
LOG=/data/adb/honor_charge_unlock.log
PIDF=/data/adb/honor_charge_unlock.pid

BATT_UE=/sys/class/power_supply/battery/uevent
IFACE=/sys/class/hw_power/interface
DC=/sys/class/hw_power/charger

# ---------- config ----------
screen_on_unlock=1
unlock_when_screen_off=1
poll_interval=0.3
temp_guard=0
protocol_poke=1
include_lvc=1
verbose=0
# explicit iin_thermal value written each cycle; the kernel clamps it to the
# per-path temp_para row on write (12000/14500 below 44C), so a large value
# is safe and takes effect instantly (no recompute delay like write-0)
max_iin=20000

if [ ! -f "$CONF" ]; then
  cat > "$CONF" <<EOF
# Honor Charge Unlock config (values take effect after daemon restart or reboot)
# 1 = on, 0 = off
screen_on_unlock=1
# also force limits while screen is off (default on: full-time unlock)
unlock_when_screen_off=1
# poll interval in seconds (fractional ok). the OS re-caps limits every ~4.5s;
# 0.3s keeps the unlocked value up ~90% of the time
poll_interval=0.3
# pause unlocking when battery temp >= this (degC*10). 0 disables the guard.
# NOTE: the kernel clamps iin_thermal to its own temp_para table anyway
# (12000/14500 below 44C, 6000 at 44-45C, 1700 at 45-50C, 0 above 50C),
# so this guard is only extra margin on top of that in-kernel ladder.
temp_guard=0
# try poking protocol enable nodes (pd/hvc/hsc) on boot and charger plug
protocol_poke=1
# include the LVC path (direct_charger) besides SCP/HSC(UFCS)
include_lvc=1
# launch boost v2: pin min=max on all clusters via perfserv_freq QoS votes
# for the launch window (ends at ActivityManager "Displayed" first frame or
# launch_boost_ms timeout, whichever first). Renewal-dominant: the proc write
# replaces the per-cluster PM-QoS min/max vote PAIR atomically and the last
# writer owns it, so a ~10-30Hz re-pin wins the race against perfserv's own
# launch caps (p4<=3.0G / p7<=3.5G) -> whole window runs at cluster max.
launch_boost=1
launch_boost_ms=2000
# scroll clamp: policy4 (big cluster) max in kHz while the finger is down,
# same QoS vote channel (100% occupancy measured at >=10Hz renewal).
# Touch source = wakeup_sources event2 counter (real touches only).
# Taobao 120Hz ladder (2026-09-07): 0.8G == 0.9G frame pacing (legacy janky
# 13.75% vs 14.50%, p99 21 vs 26ms), 0.7G+ degrades monotonically -> 0.8G.
scroll_cap=800000
# keep iAware app-preload features off (cloud may re-push values)
disable_preload=1
# --- FCM keep-alive unlock (v1.9; mechanism notes in docs/FCM通路逆向笔记.md) ---
# Honor China ROM probes "google connectivity" by HTTP-GETting google.com; on
# failure it silently drops GMS partial wakelocks (MCS push dies in doze),
# PowerGenie firewall-blocks the GMS uid, and after a 7-day grace iAware strips
# GMS apps of their background privileges. All three layers key off that probe.
fcm_unlock=1
# probe re-assert interval (seconds); also re-runs the keepalive/grace/gms keeps
fcm_interval=1800
# URLs fed to the probe (must answer HTTP 200, be reachable in CN; probe stops
# at the first success). Oversea-SIM devices short-circuit to OK anyway.
fcm_probe_urls=http://www.baidu.com,http://www.qq.com
# notifyGoogleKeepAlive(com.google.android.gms, true): freeze-exempt + unfreeze GMS
fcm_keepalive=1
# keep persist.sys.iaware_google_conn="0,1" so every boot starts a fresh 7-day grace
fcm_grace_keeper=1
# keep Settings.Secure google_service_status=1 (google components enabled)
fcm_gms_on=1
# optb region bypass (v1.9.2): flip msc.config.optb at post-fs-data so all
# china-rom google gates arm as oversea (probe/fuse/uid-firewall/iaware all
# inert). Overseas use only: changes market/COTA/OTA region identity.
region_bypass=0
# vpn_lock (v1.9.3): GMS MCS unwraps "bypassable" VPNs and direct-connects
# mtalk.google.com (GMS design, no internal flag - see docs/FCM通路逆向笔记.md
# §15). While a VPN tunnel is up, re-point the system's always-on VPN at the
# connected VPN app with lockdown=1 via the vpn_management binder: lockdown
# overrides isBypassable to false AND netd blocks the underlying network, so
# MCS can only use the tunnel. The lock is held only while the tunnel is up
# (released on drop) and never persisted (settings scrubbed right after
# apply), so a reboot can never force-start the VPN blind.
vpn_lock=0
# lsp_fix (v1.9.5): let system-scope LSPosed modules inject into
# system_server on Honor MagicOS. The ROM's PackageParser NPEs inside the
# lspd daemon (ActivityManagerInternal null in non-system_server) when it
# parses such modules, and the NPE sits behind a CN-locale-only gate.
# post-fs-data masks ro.product.locale to en-US for the parse window (early
# boot); this daemon restores zh-CN a few seconds after boot_completed.
# Needs LSPosed v2.2.0+ (Zygisk Next). Takes effect after a reboot.
lsp_fix=0
# volte_fix (v1.9.6): CN ROM ships its telephony APN DB without a type=ims
# entry for many carriers (au/KDDI 44054 here; overseas VoLTE-only networks,
# but also domestic carriers whose ims row the ROM omits - carrier-agnostic).
# Without an ims APN the IMS PDN is never established, so VoLTE registration
# is dead and the CS domain spins in NOT_REG_SEARCHING forever (constant extra
# modem signaling = standby drain). Idempotently adds one type=ims row per
# loaded SIM's operator numeric - any SIM missing its ims row gets one.
volte_fix=1
# after a first-time ims APN insert, cycle airplane mode once so the data
# stack rebuilds its profiles without a reboot (runs right after boot, and
# only when a row was actually inserted - never on later checks)
volte_radio_cycle=1
# qr_fix (v1.9.8): camera QR-scan fix. This ROM has no dedicated AF scenario
# for the QR/document scene, and the rear-main 6-frame airaw pipeline runs
# the QRFUSION multi-frame fusion for it; with AF hunting between focus peaks
# on the high-contrast QR pattern, the fused burst ghost-blurs captures
# (repeat zoom-in/out hunting needed before a scan succeeds). The module's
# qrfix/facemaskconfig.xml (QRFUSION mask entry removed) is bind-mounted over
# /odm/etc/camera/airaw/facemaskconfig.xml by post-fs-data at boot; the
# runtime branch below applies/unmounts it when the switch is toggled via the
# panel (webui_ctl restarts the daemon). No partition write, dm-verity
# untouched, off = plain umount. Default on: user-verified sharper scans.
qr_fix=1
# smartae_target (v1.9.9): rear-main AE luma target, the exposure knob the
# community asks for (reports: 过曝 / 高光压不住). Factory 200 and IDENTICAL in
# all six smartae variants (/odm/etc/camera/smartae/back{,/aperture,/tele,/wide}
# + front + others), i.e. the AE is content to average brighter than a
# high-contrast scene can hold -> sky/window edges clip and nothing pulls them
# back (HLR is also factory-off: HlrOverRatioTH=0). libSmartAEV2.so logs
# "aeTarget: %d, curLuma: %d, ratio: %f, targetEV: %f" -> Target is exactly that
# AE luma target, so lowering it is a monotonic darkening pull-down.
# Only /odm/etc/camera/smartae/back/SmartAE.xml is touched (rear main); the
# <Target> tag appears 3x there and nothing else in the file changes.
# Value: 0 = off (factory behaviour), otherwise written into <Target>.
#   200 = factory  185 = default (user-accepted round-1 value)
#   170-195 = sane band; below ~170 indoor/low-light faces go muddy-grey
#   (the AE then demands more ISO/shutter than the scene has) and above 195
#   the change stops being visible. Not a brightness slider: it re-centres AE,
#   so shadows lift back via exposure, the whole frame does not just dim.
# Delivered as a bind-mount over EROFS /odm like qr_fix: generated at runtime
# from camfix/SmartAE_back_orig.xml (never modified -> any value reproducible),
# no partition write, dm-verity untouched, off = plain umount. The camera HAL
# re-reads tuning on each camera open, so a change lands on reopening camera
# (no reboot needed). Default 185.
smartae_target=185
# sharpen_cut (v2.0.0): community question 2 (锐化太重). The HDR+ engine
# /odm/lib64/libhdrp.so reads the detail stages out of each module's hdrp_mc.xml -
# the tag paths are literal strings in that lib: /Config/RAWNR/lanczos_de/{exp,iso}%d,
# /Config/RAWNR/DetailAddBack/Layer0..2/CurrentLayer/{exp,iso}%d and the
# CHANGEREFRAWNR mirrors. In that file <Global> has RAWNRBypass=0 while
# RAW2YUV/sharpen is factory switch=0 and DE/CE/DRE/SkinSmooth are bypassed, i.e.
# what actually sharpens the rear main is RAWNR's own detail add-back - so that
# is what this knob turns down. Columns are picked from the in-file field docs:
# lanczos_de's [0,512] fixed-point gain groups (nondetail/dark+light/Face) and
# DetailAddBack's weight+scale floats; every threshold/k/count column is left
# alone. Rows whose token count does not match the schema are emitted verbatim,
# so a layout change degrades to "no edit" instead of corrupting the tuning.
# Value: percent those gains are reduced by. 0 = off (factory), 1..90.
#   35 = default   20-50 = sane band (20 barely visible, 50 already soft)
#   above ~60 the image goes visibly soft and detail starts reading as smear.
# Scope: the rear-primary (_hpb_P) module dirs listed by
# /odm/etc/camera/{hdrplite,rawhdr}/device.config -> 16 hdrp_mc.xml bind-mounts,
# each generated from its own stock file (they are NOT identical per module), so
# the variant in use keeps its own calibration numbers. Same stateless
# umount->transform->bind-mount delivery as smartae_target: no partition write,
# lands on reopening the camera, off = plain umount. Default 35.
sharpen_cut=35
verbose=0
EOF
fi
# shellcheck disable=SC1090
. "$CONF" 2>/dev/null

# merge keys added by upgrades into existing confs (template above is only
# written on first install; never clobber values already present)
conf_add() {
  grep -q "^$1=" "$CONF" 2>/dev/null || echo "$1=$2" >> "$CONF"
}
conf_add screen_on_unlock 1
conf_add unlock_when_screen_off 1
conf_add poll_interval 0.3
conf_add temp_guard 0
conf_add protocol_poke 1
conf_add include_lvc 1
conf_add max_iin 20000
conf_add launch_boost 1
conf_add launch_boost_ms 2000
conf_add scroll_cap 800000
conf_add disable_preload 1
conf_add fcm_unlock 1
conf_add fcm_interval 1800
conf_add fcm_probe_urls "http://www.baidu.com,http://www.qq.com"
conf_add fcm_keepalive 1
conf_add fcm_grace_keeper 1
conf_add fcm_gms_on 1
conf_add region_bypass 0
conf_add vpn_lock 0
conf_add lsp_fix 0
conf_add volte_fix 1
conf_add volte_radio_cycle 1
conf_add qr_fix 1
conf_add smartae_target 185
conf_add sharpen_cut 35
conf_add verbose 0
# re-source: conf_add only appends to the file, but an upgraded conf means the
# first source above ran without the new keys -> without this, fcm_* stay
# empty until the next reboot (same class of bug as the v1.8.0 template lesson)
. "$CONF" 2>/dev/null

log() {
  [ "$verbose" = "1" ] || return 0
  sz=$(wc -c < "$LOG" 2>/dev/null)
  if [ "${sz:-0}" -gt 32768 ]; then : > "$LOG"; fi
  echo "$(date '+%m-%d %H:%M:%S') $1" >> "$LOG"
}

screen_awake() {
  # Awake/Dozing/Asleep; Dozing can still be "display off" -> only Awake counts
  dumpsys power 2>/dev/null | grep -qm1 'mWakefulness=Awake'
}

do_unlock() {
  echo "$max_iin" > "$DC/direct_charger_sc/iin_thermal" 2>/dev/null
  echo "$max_iin" > "$DC/direct_charger_hsc/iin_thermal" 2>/dev/null
  [ "$include_lvc" = "1" ] && echo "$max_iin" > "$DC/direct_charger/iin_thermal" 2>/dev/null
  echo "$max_iin" > "$IFACE/iin_thermal" 2>/dev/null
  echo "$max_iin" > "$IFACE/ichg_thermal" 2>/dev/null
}

poke_protocols() {
  # best-effort; on many builds enable_charger is a read-only view kept by the
  # charge FW (values then follow the attached adapter). Harmless if ignored.
  echo "pd 1" > "$IFACE/enable_charger" 2>/dev/null
  echo "hvc 1" > "$IFACE/enable_charger" 2>/dev/null
  echo "hsc 1" > "$IFACE/enable_charger" 2>/dev/null
  echo "sc 1" > "$IFACE/enable_charger" 2>/dev/null
  echo 1 > "$IFACE/charge_turbo_enable" 2>/dev/null
}

dump_arbitration() {
  # protocol arbitration evidence after a plug event (fills in with real adapters)
  {
    echo "=== plug $(date) adapter=$(cat /sys/class/hw_power/adapter/adapter_type 2>/dev/null) support_mode=$(cat /sys/class/hw_power/adapter/support_mode 2>/dev/null)"
    echo "    max_volt=$(cat /sys/class/hw_power/adapter/max_volt 2>/dev/null) max_cur=$(cat /sys/class/hw_power/adapter/max_cur 2>/dev/null) fwver=$(cat /sys/class/hw_power/adapter/fwver 2>/dev/null)"
    dmesg | grep -E "adapter_prot_arbitration|protocol_info|chg_adapter|ufcs|pd_max_watt|pe4" | tail -30
  } >> "$LOG" 2>&1
}

# single instance (validate the pid actually is our daemon, pidfile survives reboot)
if [ -f "$PIDF" ]; then
  old=$(cat "$PIDF" 2>/dev/null)
  if [ -n "$old" ] && [ -d "/proc/$old" ] && grep -q "honor_charge_unlock/service.sh" "/proc/$old/cmdline" 2>/dev/null; then
    exit 0
  fi
  rm -f "$PIDF"
fi
echo $$ > "$PIDF"

# ---------- QR scan fix (v1.9.8): runtime switch handling ----------
# post-fs-data already applied the mount for the cold-boot case; this branch
# runs BEFORE the boot wait so a panel toggle (webui_ctl restarts the daemon)
# takes effect immediately: qr_fix=1 (re)mounts, qr_fix=0 unmounts. Idempotent.
QR_TGT=/odm/etc/camera/airaw/facemaskconfig.xml
QR_STF=/data/adb/honor_charge_unlock.qr
if [ "$qr_fix" = "1" ] && [ -f "$MODDIR/qrfix/facemaskconfig.xml" ] && [ -f "$QR_TGT" ]; then
  if ! grep -aq "facemaskconfig.xml" /proc/mounts 2>/dev/null; then
    mount --bind "$MODDIR/qrfix/facemaskconfig.xml" "$QR_TGT" 2>/dev/null
  fi
  if grep -aq "facemaskconfig.xml" /proc/mounts 2>/dev/null; then
    echo "on" > "$QR_STF" 2>/dev/null
  else
    echo "mount-failed" > "$QR_STF" 2>/dev/null
  fi
else
  umount "$QR_TGT" 2>/dev/null
  echo "off" > "$QR_STF" 2>/dev/null
fi

# ---------- SmartAE exposure knob (v1.9.9): numeric, bind-mounted ----------
# Regenerated from the pristine module copy on every daemon start, so the knob
# is stateless: any value (including 0 = factory) is reachable without reflashing
# or tracking previous state. The camera HAL re-reads tuning per open, so the
# value lands when the camera is reopened - no reboot, no daemon-loop polling.
# Content check (not /proc/mounts) decides success: EROFS binds surface there as
# the underlying dm-* block device, so path matching is unreliable on this ROM.
CAM_ORIG=$MODDIR/camfix/SmartAE_back_orig.xml
CAM_TGT=/odm/etc/camera/smartae/back/SmartAE.xml
CAM_DIR=/data/adb/camfix
CAM_GEN=$CAM_DIR/SmartAE_back.xml
CAM_STF=/data/adb/honor_charge_unlock.cam
cam_target=${smartae_target:-185}
case "$cam_target" in ''|*[!0-9]*) cam_target=185 ;; esac
if [ "$cam_target" -gt 0 ] && [ -f "$CAM_ORIG" ] && [ -f "$CAM_TGT" ]; then
  mkdir -p "$CAM_DIR" 2>/dev/null
  sed "s|<Target>[0-9]*</Target>|<Target>$cam_target</Target>|g" "$CAM_ORIG" > "$CAM_GEN.new" 2>/dev/null
  n=$(grep -c "<Target>$cam_target</Target>" "$CAM_GEN.new" 2>/dev/null)
  if [ "${n:-0}" -eq 3 ] && [ -s "$CAM_GEN.new" ]; then
    mv "$CAM_GEN.new" "$CAM_GEN"; chmod 644 "$CAM_GEN" 2>/dev/null
    if ! grep -q "<Target>$cam_target</Target>" "$CAM_TGT" 2>/dev/null; then
      umount "$CAM_TGT" 2>/dev/null
      mount --bind "$CAM_GEN" "$CAM_TGT" 2>/dev/null
    fi
  else
    rm -f "$CAM_GEN.new"
  fi
  if grep -q "<Target>$cam_target</Target>" "$CAM_TGT" 2>/dev/null; then
    echo "on $cam_target" > "$CAM_STF" 2>/dev/null
  else
    echo "mount-failed $cam_target" > "$CAM_STF" 2>/dev/null
  fi
else
  umount "$CAM_TGT" 2>/dev/null
  echo "off" > "$CAM_STF" 2>/dev/null
fi

# ---------- HDR+ sharpen knob (v2.0.0): numeric, one bind-mount per module ----------
# Same stateless delivery as smartae_target: umount first so the transform always
# reads the stock tuning, then bind-mount the generated file. No daemon-loop
# polling - a panel toggle re-runs this through webui_ctl's daemon restart, and
# the camera picks the new tuning up on its next open.
# Success is proven per file by reading the <!--shpN--> marker back through the
# /odm path (content, not /proc/mounts - see the note above), and by the row
# count awk reports: only the complete schema (both lanczos_de blocks + all three
# DetailAddBack layers in both trees) is mounted, so a ROM that renamed or
# re-laid-out these columns leaves the tuning untouched instead of half-edited.
SHP_AWK=$MODDIR/camfix/sharpen.awk
SHP_DIR=/data/adb/camfix
SHP_STF=/data/adb/honor_charge_unlock.shp
shp_cut=${sharpen_cut:-35}
case "$shp_cut" in ''|*[!0-9]*) shp_cut=35 ;; esac
[ "$shp_cut" -gt 90 ] && shp_cut=90
shp_list=""
for shp_b in /odm/etc/camera/hdrplite /odm/etc/camera/rawhdr; do
  # _hpb_P = rear primary (the module the complaints are about); _hpb_S entries
  # (ultrawide/tele) are deliberately not touched.
  for shp_d in $(grep '_hpb_P=' "$shp_b/device.config" 2>/dev/null | sed 's|.*=||' | tr -d '\r'); do
    [ -f "${shp_d}hdrp_mc.xml" ] && shp_list="$shp_list ${shp_d}hdrp_mc.xml"
  done
done
shp_want=0
for shp_t in $shp_list; do shp_want=$((shp_want + 1)); done
if [ "$shp_cut" -gt 0 ] && [ -n "$shp_list" ] && [ -f "$SHP_AWK" ]; then
  mkdir -p "$SHP_DIR" 2>/dev/null
  shp_i=0; shp_ok=0
  for shp_t in $shp_list; do
    shp_i=$((shp_i + 1))
    shp_g="$SHP_DIR/hdrp_mc_$shp_i.xml"
    umount "$shp_t" 2>/dev/null
    awk -v cut="$shp_cut" -v cnt="$shp_g.cnt" -f "$SHP_AWK" "$shp_t" > "$shp_g.new" 2>/dev/null
    nr=$(cat "$shp_g.cnt" 2>/dev/null); rm -f "$shp_g.cnt" 2>/dev/null
    case "$nr" in ''|*[!0-9]*) nr=0 ;; esac
    if [ -s "$shp_g.new" ] && [ "$nr" -ge 100 ]; then
      mv "$shp_g.new" "$shp_g"; chmod 644 "$shp_g" 2>/dev/null
      mount --bind "$shp_g" "$shp_t" 2>/dev/null
    else
      rm -f "$shp_g.new"
    fi
    grep -aq "shp$shp_cut" "$shp_t" 2>/dev/null && shp_ok=$((shp_ok + 1))
  done
  # prune generated files from a previous, larger target set
  for shp_old in "$SHP_DIR"/hdrp_mc_*.xml; do
    [ -f "$shp_old" ] || continue
    shp_k=$(basename "$shp_old" | tr -dc '0-9')
    [ "${shp_k:-0}" -gt "$shp_i" ] && rm -f "$shp_old"
  done
  if [ "$shp_ok" -gt 0 ]; then
    echo "on $shp_cut $shp_ok/$shp_want" > "$SHP_STF" 2>/dev/null
  else
    echo "mount-failed $shp_cut 0/$shp_want" > "$SHP_STF" 2>/dev/null
  fi
else
  for shp_t in $shp_list; do umount "$shp_t" 2>/dev/null; done
  echo "off" > "$SHP_STF" 2>/dev/null
fi

# wait for boot
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done
sleep 10

log "daemon started pid=$$"

# ---------- launch boost (v2.0, perfserv_freq QoS pin) ----------
# Start  : ActivityManager "Start proc <pid>:<pkg> ... for [next-]top-activity"
# End    : ActivityTaskManager "Displayed <pkg>" (first frame) or ms timeout
# Method : write min=max pins to /proc/powerhal_cpu_ctrl/perfserv_freq. That
#          proc write atomically replaces the per-cluster PM-QoS min/max vote
#          PAIR (slot->cluster: 0-3=policy0, 4-6=policy4, 7=policy7) and the
#          last writer owns the pair, so re-pinning at ~10-30Hz wins the race
#          against perfserv's own launch caps (p4<=3.0G / p7<=3.5G): the whole
#          window runs pinned at cluster max (4.21G super core included).
#          (v1.6 raised scaling_min_freq via sysfs instead: cpufreq clamps
#          sysfs-min into the QoS range, so it could never pass 3.5G.)
# Safety : Displayed releases early; epoch prevents stale restores; hard cap
#          launch_boost_ms<=5000; zero-fork fifo pacer for the renewal ticks.
NODE=/proc/powerhal_cpu_ctrl/perfserv_freq
FG_FIF=/data/local/tmp/.hcu_tick
SC_FIF=/data/local/tmp/.hcu_tick2
FG_FLAG=/data/local/tmp/.hcu_lb_active
LB_EPOCH=/data/local/tmp/.hcu_lb_epoch
FG_P0MAX=2700000; FG_P4MAX=3500000; FG_P7MAX=4210000; FG_PMIN=300000
rm -f $FG_FLAG 2>/dev/null   # stale flag would pause scroll clamp until next boost
[ "$launch_boost_ms" -gt 5000 ] 2>/dev/null && launch_boost_ms=5000
lb_boost_on() {
  echo 0 $FG_P0MAX $FG_P0MAX > $NODE 2>/dev/null
  echo 4 $FG_P4MAX $FG_P4MAX > $NODE 2>/dev/null
  echo 7 $FG_P7MAX $FG_P7MAX > $NODE 2>/dev/null
  : > $FG_FLAG 2>/dev/null
}
lb_boost_off() {
  echo 0 $FG_PMIN $FG_P0MAX > $NODE 2>/dev/null
  echo 4 $FG_PMIN $FG_P4MAX > $NODE 2>/dev/null
  echo 7 $FG_PMIN $FG_P7MAX > $NODE 2>/dev/null
  rm -f $FG_FLAG 2>/dev/null
}
fg_fifo() {  # $1 = fifo path; one long-sleep holder, readers use read -t (no fork)
  [ -p "$1" ] || { rm -f "$1"; mkfifo "$1" 2>/dev/null; }
  pgrep -f "sleep 99999999" >/dev/null 2>&1 || sleep 99999999 > "$1" 2>/dev/null &
}
lb_renew() {  # $1=myepoch: re-pin every 100ms until epoch moves or ticks run out
  n=$(( ${launch_boost_ms:-2000} / 100 ))
  while [ $n -gt 0 ]; do
    lb_boost_on
    read -t 0.1 x < "$FG_FIF" 2>/dev/null || :
    [ "$(cat $LB_EPOCH 2>/dev/null)" != "$1" ] && return
    n=$((n-1))
  done
  [ "$(cat $LB_EPOCH 2>/dev/null)" = "$1" ] && lb_boost_off
}
lb_watch() {
  fg_fifo "$FG_FIF"
  echo 0 > "$LB_EPOCH"
  logcat -v brief -s ActivityManager:I ActivityTaskManager:I 2>/dev/null | while read -r line; do
    case "$line" in
      *"Start proc "*for\ top-activity*|*"Start proc "*for\ next-top-activity*)
        n=$(( $(cat "$LB_EPOCH") + 1 )); echo "$n" > "$LB_EPOCH"
        lb_boost_on
        lb_renew "$n" &
        ;;
      Displayed\ *)
        n=$(( $(cat "$LB_EPOCH") + 1 )); echo "$n" > "$LB_EPOCH"
        lb_boost_off
        ;;
    esac
  done
}
if [ "$launch_boost" = "1" ]; then
  lb_watch &
  log "launch_boost watcher started (v2 perfserv_freq QoS pin)"
fi
# ---------- scroll cap (v2, QoS vote channel) ----------
# Touch = wakeup_sources event2 event_count deltas (real finger only; injected
# input is invisible to it). While touched (+hold ticks), re-write the policy4
# vote pair with max=scroll_cap at ~20Hz; perfserv's scroll economy writes lose
# the race (100% occupancy measured). Paused while a launch boost owns the pair
# (flag file), resumed after.
sc_watch() {
  [ -p "$SC_FIF" ] || { rm -f "$SC_FIF"; mkfifo "$SC_FIF" 2>/dev/null; }
  pgrep -f "sleep 99999998" >/dev/null 2>&1 || sleep 99999998 > "$SC_FIF" 2>/dev/null &
  last_ev=X; touch_t=-99; tick=0; mode=IDLE
  while :; do
    tick=$((tick+1))
    read -t 0.1 x < "$SC_FIF" 2>/dev/null || :
    if [ $((tick % 2)) -eq 0 ]; then
      ev=$(grep -m1 -s ^event2 /proc/wakeup_sources 2>/dev/null)
      case $ev in "$last_ev") ;; *) touch_t=$tick; last_ev=$ev ;; esac
    fi
    if [ -f "$FG_FLAG" ]; then mode=BOOST; continue; fi
    if [ $((tick - touch_t)) -lt ${scroll_hold_ticks:-4} ]; then
      echo 4 $FG_PMIN $scroll_cap > $NODE 2>/dev/null
      echo 4 $FG_PMIN $scroll_cap > $NODE 2>/dev/null
      mode=SCROLL
    elif [ "$mode" = SCROLL ]; then
      echo 4 $FG_PMIN $FG_P4MAX > $NODE 2>/dev/null
      mode=IDLE
    fi
  done
}
if [ "$scroll_cap" != "0" ] && [ -n "$scroll_cap" ]; then
  sc_watch &
  log "scroll_cap watcher started (v2 QoS cap=$scroll_cap)"
fi

# ---------- FCM keep-alive unlock (v1.9) ----------
# All calls are uid-1000 binder transactions on the "pgservice" service
# (PGManagerService, IPGManager AIDL):
#   tx12 setPgConfig(6 /*CONFIG_TYPE_GOOGLE_CTRL*/, 0, urls)
#        -> PGGoogleServicePolicy probes those URLs instead of google.com;
#           first HTTP 200 flips the whole ROM into "google connected" state
#           (wakelock filter off, no uid firewall, iAware grace maintained).
#   tx21 notifyGoogleKeepAlive("com.google.android.gms", true)
#        -> setPgShouldNotFreeze + immediate unfreeze of GMS processes.
# Root-only, no persistent processes, no LSP injection (broken on Honor).
FCM_STF=/data/adb/honor_charge_unlock.fcm
fcm_urls=$(printf '%s' "$fcm_probe_urls" | tr -d ' \t\r' | tr ',' ' ')
fcm_avail=1

fcm_assert() {
  [ "$fcm_avail" = "1" ] || return 2
  [ -n "$fcm_urls" ] || { echo "off no-urls" > "$FCM_STF" 2>/dev/null; return 1; }
  n=0
  for u in $fcm_urls; do n=$((n+1)); done
  args="i32 6 i32 0 i32 $n"
  for u in $fcm_urls; do args="$args s16 $u"; done
  out=$(su 1000 -c "service call pgservice 12 $args" 2>&1)
  case "$out" in
    *00000001*) st=ok ;;
    *"Can't find service"*|*"not found"*)
      fcm_avail=0; echo "nosvc" > "$FCM_STF" 2>/dev/null
      log "fcm: pgservice not available, fcm_unlock disabled this boot"
      return 2 ;;
    *) return 1 ;;   # PG not ready yet -> retry shortly
  esac
  if [ "$fcm_keepalive" = "1" ]; then
    su 1000 -c "service call pgservice 21 s16 com.google.android.gms i32 1" >/dev/null 2>&1
  fi
  if [ "$fcm_grace_keeper" = "1" ]; then
    # iAware reads this once per boot: disconn=0(conned-since-epoch), conn=1
    # -> grace period (default 7d, cloud key google_delaytime) always fresh
    [ "$(getprop persist.sys.iaware_google_conn)" != "0,1" ] && \
      setprop persist.sys.iaware_google_conn "0,1" 2>/dev/null
  fi
  if [ "$fcm_gms_on" = "1" ] && pm path com.google.android.gms >/dev/null 2>&1; then
    [ "$(settings get secure google_service_status 2>/dev/null)" != "1" ] && \
      settings put secure google_service_status 1 2>/dev/null
  fi
  echo "$st n=$n" > "$FCM_STF" 2>/dev/null
  log "fcm: probe urls injected ($n) + keepalive/grace/gms asserted"
  # verify the ACTUAL probe verdict (injection success != probe success);
  # async so the charge-reassert loop never stalls. Log volume evicts
  # hundreds of lines per second: anchor the dump at the assert timestamp
  # (-T); a line-count window (-t 300) had already rotated out by the
  # time we looked (8s later) on chatty builds.
  {
    ts=$(date '+%m-%d %H:%M:%S.000')
    sleep 8
    lc=$(logcat -d -T "$ts" -s PGGoogleServicePolicy:D 2>/dev/null)
    case "$lc" in
      *"connect google success"*) v="probe:ok" ;;
      *"connect google failed"*) v="probe:fail" ;;
      *) v="" ;;
    esac
    if [ -n "$v" ]; then
      echo "$st n=$n $v" > "$FCM_STF" 2>/dev/null
      log "fcm: probe verdict $v"
    fi
  } &
  return 0
}

fcm_last=0
fcm_boot_boost=5   # dense 60s re-asserts right after daemon start (PowerGenie re-push race)

# ---------- VPN lock (v1.9.3) ----------
# GMS's MCS network selector (chyq.k, GMS 26.32 code-level analysis) checks
# VpnTransportInfo.isBypassable() on the active network: if the VPN declares
# allowBypass, it unwraps the VPN and binds the underlying WiFi/Cell to reach
# mtalk.google.com directly (dead in CN). No GMS flag can disable that, but a
# SYSTEM lockdown does: "always-on VPN + block connections without VPN"
# overrides bypassable to false and netd deletes the underlying routes.
# Applied here as root through the vpn_management binder (IVpnManager):
#   tx15 setAlwaysOnVpnPackage(user 0, pkg, lockdown, allowlist [])
#        - returns true/false; a non-VPN package is a harmless no-op
#        - persists app+lockdown into Settings.Secure (saveAlwaysOnPackage)
#          -> scrubbed right after, so the lock lives in memory only and a
#        reboot never force-starts the VPN with its tunnel missing (blackout)
#   tx16/17 read back the package / lockdown flag (used to verify + to clean
#        up a lock left over from a daemon kill while the tunnel stayed up)
# Parcel layout via service(1): i32 userId, s16 pkg, i32 bool (1 byte read,
# realigned), i32 0 = empty allowlist; "i32 -1" writes a length of -1 which
# the server reads as pkg=null -> releases always-on AND lockdown.
VPN_STF=/data/adb/honor_charge_unlock.vpn
VPN_TX_SET=15
VPN_TX_LOCK=17
vpn_tx() { service call vpn_management "$@" 2>/dev/null; }
vpn_is_locked() { case "$(vpn_tx $VPN_TX_LOCK i32 0)" in *00000001*) return 0 ;; esac; return 1; }
vpn_apply() {  # $1 = connected VPN package
  out=$(vpn_tx $VPN_TX_SET i32 0 s16 "$1" i32 1 i32 0)
  case "$out" in
    *Result:*00000001*)
      # the server persisted app+lockdown into Settings.Secure; scrub it so
      # the lock lives in memory only (a reboot must never force-start the
      # VPN with no tunnel up - that is a total-connectivity lockdown trap)
      settings delete secure always_on_vpn_app 2>/dev/null
      settings delete secure always_on_vpn_lockdown 2>/dev/null
      return 0 ;;
  esac
  return 1
}
vpn_release() { vpn_tx $VPN_TX_SET i32 0 i32 -1 i32 0 i32 0 >/dev/null 2>&1; }
# a lockdown the user configured themselves in system Settings (settings keys
# non-empty) is THEIR config: never apply-scrub over it, never release it
vpn_user_cfg() { [ "$(settings get secure always_on_vpn_app 2>/dev/null)" != "null" ]; }
# The active tunnel's VpnTransportInfo.bypassable flag. The whole point of the
# lockdown is to stop GMS's MCS (chyq.k) from UNWRAPPING a bypassable VPN to
# reach mtalk directly. If the tunnel is ALREADY non-bypassable (bypassable=false)
# there is nothing to lock - MCS cannot unwrap it anyway. Worse, applying the
# lockdown to a manual VPN (startSession by the app, not a startService-able
# always-on service) makes system_server's Vpn.setAlwaysOnPackage ->
# startAlwaysOnVpn fail to bring up a real session, and the system ROLLS BACK the
# lock after the lockdown route-stripping has already killed the live session
# (proven on-device: apply -> 10ms "UnderlyingNW Switch to null" -> session
# UNKNOWN_ERROR -> system auto-releases). So: only apply when bypassable=true.
vpn_is_bypassable() {
  case "$(dumpsys vpn_management 2>/dev/null | grep -a 'VpnTransportInfo{' | head -n 1)" in
    *bypassable=true*) return 0 ;;
    *) return 1 ;;
  esac
}
vpn_lock_watch() {
  locked=0   # 0=none, 1=ephemeral lock applied by us, 2=user's own config
  echo idle > "$VPN_STF" 2>/dev/null
  while :; do
    if grep -q 'tun[0-9]' /proc/net/dev 2>/dev/null; then
      if [ "$locked" = "0" ]; then
        if vpn_user_cfg; then
          locked=2
          echo "locked (user-config)" > "$VPN_STF" 2>/dev/null
          log "vpn_lock: tunnel up under user-configured always-on, adopting"
        else
          # one dumpsys per poll; derive both the active package and the
          # tunnel's bypassable flag from it
          ds=$(dumpsys vpn_management 2>/dev/null)
          # [Legacy VPN] is the placeholder when no app VPN is connected; the
          # server rejects it as always-on anyway
          pkg=$(printf '%s\n' "$ds" | sed -n 's/^[[:space:]]*Active package name: //p' | head -n 1)
          case "$pkg" in
            ""|*"[Legacy VPN]"*) : ;;
            *)
              # SAFETY-FIRST (this module is distributed; a user's live VPN must
              # NEVER be killed by us). We do NOT call setAlwaysOnPackage(lockdown)
              # on a live manual VpnService: on this ROM it strips the underlying
              # routes (killing the live session) and system_server's
              # startAlwaysOnVpn then fails to bring up a manual tunnel and rolls
              # the lock back - net effect is always "tunnel dead + lock off".
              # So we only ever OBSERVE and report the tunnel's bypassable state:
              #   - non-bypassable (bypassable=false): GMS's MCS cannot unwrap it,
              #     so it is already forced through the tunnel - nothing to lock.
              #   - bypassable (bypassable=true): we CANNOT safely force it
              #     non-bypassable from the shell without killing the session, so
              #     we report it and let the user switch to global mode with a
              #     non-bypassable VPN (the only combo that both routes GMS through
              #     the tunnel AND keeps the tunnel alive). Do NOT latch (locked
              #     stays 0) so a mode/VPN change is picked up on the next poll.
              if printf '%s\n' "$ds" | grep -a 'VpnTransportInfo{' | head -n 1 | grep -aq 'bypassable=true'; then
                [ "$(cat "$VPN_STF" 2>/dev/null)" != "skip-bypassable ($pkg)" ] && \
                  { echo "skip-bypassable ($pkg)" > "$VPN_STF" 2>/dev/null;
                   log "vpn_lock: tunnel $pkg is BYPASSABLE; not applying lockdown (would kill the live session) - use global mode with a non-bypassable VPN"; }
              else
                [ "$(cat "$VPN_STF" 2>/dev/null)" != "skip ($pkg)" ] && \
                  { echo "skip ($pkg)" > "$VPN_STF" 2>/dev/null;
                   log "vpn_lock: tunnel $pkg already non-bypassable, no lock needed"; }
              fi ;;
          esac
        fi
      fi
    else
      if [ "$locked" = "1" ]; then
        # the user may have configured their own always-on while our lock was
        # up - in that case leave the state (and their settings) alone
        if vpn_user_cfg; then
          locked=2
        else
          vpn_release
          echo idle > "$VPN_STF" 2>/dev/null
          log "vpn_lock: lockdown released (tunnel down)"
        fi
      fi
      [ "$locked" = "0" ] && echo idle > "$VPN_STF" 2>/dev/null
    fi
    sleep 5
  done
}
# The GMS-push VPN monitor is an OBSERVE-ONLY indicator, gated by the user
# toggle (vpn_lock=1) since it's mainly a debugging aid and the 5s poll is not
# free. It reads the active tunnel's bypassable flag + whether GMS is routed
# through it and reports to the panel for guidance. It NEVER applies a lockdown
# (setAlwaysOnPackage would kill a live manual tunnel on this ROM). The stale-
# lock cleanup runs in BOTH branches in case an older active-lock era left a
# lock in system_server memory: release ONLY our own ephemeral lock (settings
# show no configured always-on) and only with the tunnel down.
if [ "$(settings get secure always_on_vpn_app 2>/dev/null)" = "null" ] && vpn_is_locked && \
   ! grep -q 'tun[0-9]' /proc/net/dev 2>/dev/null; then
  vpn_release
  log "vpn_monitor: released stale lockdown from previous era"
fi
if [ "$vpn_lock" = "1" ]; then
  vpn_lock_watch &
  log "vpn_monitor: observe-only watcher started"
else
  echo off > "$VPN_STF" 2>/dev/null
fi

# ---------- LSPosed system-scope fix (v1.9.5) ----------
# post-fs-data masked ro.product.locale to en-US (pre-zygote) so the lspd
# daemon's module parse skips the CN-only NPE branch that drops system-scope
# LSPosed modules from the system_server list. The parse window is over once
# system_server is up, so restore zh-CN shortly after boot_completed; the
# user never sees the mask. If the daemon starts after the restore is due
# (e.g. daemon killed + restarted), the locale is already zh-CN and the
# restore below is a harmless no-op.
LSP_STF=/data/adb/honor_charge_unlock.lsp
if [ "$lsp_fix" = "1" ]; then
  (
    until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 1; done
    sleep 5
    RP=/data/adb/ksu/bin/resetprop
    [ -x "$RP" ] || RP=resetprop
    "$RP" ro.product.locale.language zh
    "$RP" ro.product.locale.region CN
    echo "$(date) restored" > "$LSP_STF" 2>/dev/null
  ) &
  log "lsp_fix: locale mask restore scheduled (boot_completed+5s)"
else
  echo off > "$LSP_STF" 2>/dev/null
fi

# ---------- VoLTE APN fix (v1.9.6) ----------
# Reverse-engineering trail: Settings toggle is ON (hn_volte_user_switch_N=1),
# carrier config says volte available (carrier_volte_available_bool=true) and
# the framework gate passes (com.android.ims.HwImsManagerInner#
# isVolteEnabledByPlatform -> device config && carrier config && GBA, all
# true) - yet MMTEL stays UNAVAILABLE. The actual blocker is data, not code:
# this ROM's APN DB has no type=ims row for 44054 (au), while the CN carrier
# rows carry apn=ims/type=ims (which is exactly why VoLTE "works on other
# cards"). Without it the IMS PDN is never set up; once the row exists the
# framework builds its built-in "DEFAULT IMS" profile (DNN "ims") and the
# network answers with P-CSCF + QCI5 - verified live on au. Long-term cost of
# the missing row: CS domain stuck in NOT_REG_SEARCHING, i.e. the modem keeps
# re-attempting voice registration that can never succeed on a VoLTE-only
# network (extra signaling both ways, also seen in the standby drain trace).
# Watcher: ensures one type=ims row per loaded SIM operator numeric, re-run
# only when the numeric set changes (SIM swap); idempotent, never touches
# existing rows.
VOLTE_STF=/data/adb/honor_charge_unlock.volte
volte_ensure() {  # $1 = operator numeric (e.g. 44054) -> prints ok|ins|err
  num=$1
  mcc=$(printf '%s' "$num" | cut -c 1-3)
  mnc=$(printf '%s' "$num" | cut -c 4-)
  [ -n "$mnc" ] || { echo err; return; }
  got=$(content query --uri content://telephony/carriers --projection _id \
        --where "numeric='$num' AND type='ims'" 2>/dev/null)
  case "$got" in *Row:*|*"_id="*) echo ok; return ;; esac
  if content insert --uri content://telephony/carriers \
      --bind name:s:'IMS' --bind apn:s:'ims' --bind type:s:'ims' \
      --bind numeric:s:"$num" --bind mcc:s:"$mcc" --bind mnc:s:"$mnc" \
      --bind protocol:s:'IPV4V6' --bind roaming_protocol:s:'IPV4V6' \
      --bind authtype:i:0 --bind carrier_enabled:i:1 >/dev/null 2>&1; then
    echo ins
  else
    echo err
  fi
}
volte_radio_cycle() {
  cmd connectivity airplane-mode enable  >/dev/null 2>&1
  sleep 5
  cmd connectivity airplane-mode disable >/dev/null 2>&1
}
volte_watch() {
  last=X; n=0
  while :; do
    nums=$(getprop gsm.sim.operator.numeric 2>/dev/null | tr -d ' ')
    clean=""
    OLDIFS=$IFS; IFS=,
    for p in $nums; do
      case "$p" in ""|-|*-*) ;; *)
        case ",$clean," in *",$p,"*) ;; *) clean="${clean:+$clean,}$p" ;; esac ;;
      esac
    done
    IFS=$OLDIFS
    if [ -z "$clean" ]; then
      echo wait-sim > "$VOLTE_STF" 2>/dev/null
      # fast re-poll while boot settles (3 min), then re-check every 5 min
      n=$((n+1)); [ $n -le 18 ] && sleep 10 || sleep 300
      continue
    fi
    if [ "$clean" != "$last" ]; then
      last=$clean
      ins=0; err=0
      for p in $(printf '%s' "$clean" | tr , ' '); do
        st=$(volte_ensure "$p")
        case $st in ok) : ;; ins) ins=$((ins+1)) ;; *) err=$((err+1)) ;; esac
      done
      if [ $err -gt 0 ]; then
        echo "err ($clean)" > "$VOLTE_STF" 2>/dev/null
        log "volte_fix: content provider error for $clean, retry in 2 min"
        last=X
        sleep 120
        continue
      fi
      if [ $ins -gt 0 ] && [ "$volte_radio_cycle" = "1" ]; then
        echo "radio-cycle ($clean)" > "$VOLTE_STF" 2>/dev/null
        sleep 3
        volte_radio_cycle
      fi
      echo "ok $clean inserted=$ins" > "$VOLTE_STF" 2>/dev/null
      log "volte_fix: ims APN ensured for $clean (inserted=$ins, radio_cycle=$([ $ins -gt 0 ] && echo 1 || echo 0))"
    else
      echo "ok $clean" > "$VOLTE_STF" 2>/dev/null
    fi
    sleep 300
  done
}
if [ "$volte_fix" = "1" ]; then
  volte_watch &
  log "volte_fix: ims-APN watcher started"
else
  echo off > "$VOLTE_STF" 2>/dev/null
fi

prev_charging=0
cycle=0
applied=0
while :; do
  if [ -f /data/adb/honor_charge_unlock.paused ]; then
    sleep 1; continue
  fi
  # refresh inputs every 10 cycles; writes run every cycle
  if [ $((cycle % 10)) -eq 0 ]; then
    ue=$(cat "$BATT_UE" 2>/dev/null)
    status=${ue#*POWER_SUPPLY_STATUS=}; status=${status%%$'\n'*}
    temp=${ue#*POWER_SUPPLY_TEMP=}; temp=${temp%%$'\n'*}
    online=$(cat /sys/class/power_supply/usb/online 2>/dev/null)
    # honor fast-charge heads keep usb/online=0 even while delivering 11V: charge
    # detection must also accept the battery status, or the unlock NEVER runs on
    # exactly the adapters it exists for (66W/80W heads)
    charging=0
    [ "$online" = "1" ] && charging=1
    case $status in Charging|Full) charging=1 ;; esac
    if [ "$protocol_poke" = "1" ] && [ "$charging" = "1" ] && [ "$prev_charging" != "1" ]; then
      poke_protocols; log "protocol poke on plug"
      { sleep 8; dump_arbitration; } &
    fi
    prev_charging=$charging
    want=0
    if [ "$charging" = "1" ]; then
      if [ "$unlock_when_screen_off" = "1" ]; then want=1
      elif [ "$screen_on_unlock" = "1" ] && screen_awake; then want=1; fi
    fi
    guarded=0
    [ "$temp_guard" != "0" ] && [ "${temp:-0}" -ge "$temp_guard" ] 2>/dev/null && guarded=1
    [ "$guarded" = "1" ] && want=0
  fi
  if [ "$want" = "1" ]; then
    do_unlock
    applied=$((applied + 1))
    [ $((applied % 600)) -eq 1 ] && \
      log "unlock applied (status=$status temp=$temp sc=$(cat "$DC/direct_charger_sc/iin_thermal" 2>/dev/null) hsc=$(cat "$DC/direct_charger_hsc/iin_thermal" 2>/dev/null))"
  fi
  # re-assert preload-disable every ~60 cycles (cloud config may re-push)
  if [ "$disable_preload" = "1" ] && [ $((cycle % 60)) -eq 0 ]; then
    [ "$(getprop persist.sys.iaware.activitypreload.version)" != "0" ] && setprop persist.sys.iaware.activitypreload.version 0
    [ "$(getprop persist.sys.iaware.preloadoptenable)" != "0" ] && setprop persist.sys.iaware.preloadoptenable 0
    [ "$(getprop persist.sys.iaware.touchdownpreloadenable)" != "0" ] && setprop persist.sys.iaware.touchdownpreloadenable 0
  fi
  # FCM keep-alive: re-assert on a wall-clock schedule (default 30 min), not
  # per-cycle; piggybacks the existing loop so no extra wakeup is created.
  # date(1) runs only every 90 cycles (~27s plugged / 15min unplugged).
  # Boot boost: PowerGenie re-pushes the stock google list during its own boot,
  # after our first assert -> dense re-asserts (60s x5) close that race window.
  if [ "$fcm_unlock" = "1" ] && [ $((cycle % 90)) -eq 0 ] && [ "$fcm_avail" = "1" ]; then
    now=$(date +%s)
    fcmint=${fcm_interval:-1800}
    [ "${fcm_boot_boost:-0}" -gt 0 ] && fcmint=60
    if [ $((now - fcm_last)) -ge $fcmint ]; then
      if fcm_assert; then
        fcm_last=$now
        [ "${fcm_boot_boost:-0}" -gt 0 ] && fcm_boot_boost=$((fcm_boot_boost-1))
      else
        fcm_last=$((now - $fcmint + 120))   # retry in ~2 min
      fi
    fi
  fi
  cycle=$((cycle + 1))

  # power: fight is only meaningful while a charger is connected. Fast poll
  # (0.3s) when charging, deep 10s sleep otherwise -> ~zero idle cost.
  if [ "$charging" != "1" ]; then
    sleep 10
    continue
  fi
  sleep "$poll_interval"
done
